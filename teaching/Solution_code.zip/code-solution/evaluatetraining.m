function accuracy = evaluatetraining(nn_params, options)

X = options.data;
y = options.labels;
hidden_layer_size = options.hidden_size;
input_layer_size = options.input_size;
classes = options.output_size;

Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 classes, (hidden_layer_size + 1));

pred = predict(Theta1, Theta2, X);

accuracy = mean(double(pred == y)) * 100;

