function [J,grad] = nnCostFunction(nn_params, ...
                                   input_layer_size, ...
                                   hidden_layer_size, ...
                                   classes, ...
                                   X, labels, prior, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, classes, ...
%   X, labels, prior, lambda) computes the cost and gradient of the 
%   neural network. The parameters for the neural network are "unrolled" 
%   into the vector nn_params and need to be converted back into the weight
%   matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network
Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
                 hidden_layer_size, (input_layer_size + 1));

Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
                 classes, (hidden_layer_size + 1));

m = size(X, 1);
K = size(labels,2);
unl = m-sum(sum(labels));
pos = sum(labels);  % Size of each positive labeled dataset
pos = pos(:);
prior = prior(:);
         
%% Forward Propagation (Vectorized Form)
y_0 = [ones(1,m);X'];
z_1 = Theta1*y_0;
y_1 = z_1;
y_1(y_1 <= 0) = 0;
y_1 = [ones(1,m);y_1];
z_2 = Theta2*y_1;
y_2 = z_2;

%% Backward Propagation (Vectorized Form)
alpha = zeros(K,m);
alpha(y_2 > 1) = 1;
alpha(y_2<=1 & y_2>=-1) = 0.5;
alpha = bsxfun(@rdivide,alpha,unl);
alpha(:,1:m-unl) = 0;
temp_unl = alpha;
delta2 = zeros(K,m);
delta2(logical(labels)') = 1;
delta2 = bsxfun(@times,delta2,-prior./pos);
temp_lab = delta2;
delta2 = delta2 + alpha;
delta1 = Theta2(:,2:end)'*delta2.*(z_1>0);

%% Gradient Computation (Vectorized Form)
Theta1_grad = delta1*y_0';
Theta1_grad(:,2:end) = Theta1_grad(:,2:end) + 2*lambda*Theta1(:,2:end);
Theta2_grad = delta2*y_1';
Theta2_grad(:,2:end) = Theta2_grad(:,2:end) + 2*lambda*Theta2(:,2:end);

%% Cost Computation (Vectorized Form)
temp_unl = temp_unl.*y_2;
temp_unl(y_2<=1 & y_2>=-1) = temp_unl(y_2<=1 & y_2>=-1)+0.5;
temp_unl(:,1:m-unl) = 0;
J = sum(sum(temp_lab.*y_2))+sum(sum(temp_unl))+...
    lambda*(sum(sum(Theta1(:,2:end).^2))+... % regularizer term
    sum(sum(Theta2(:,2:end).^2)));           % regularizer term


% Unroll gradients
grad = [Theta1_grad(:) ; Theta2_grad(:)];

end
