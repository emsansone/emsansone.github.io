function p = predict(Theta1, Theta2, X)
%PREDICT Predict the label of an input given a trained neural network
%   p = PREDICT(Theta1, Theta2, X) outputs the predicted label of X given the
%   trained weights of a neural network (Theta1, Theta2)

% Useful values
m = size(X, 1);
num_labels = size(Theta2, 1);

p = zeros(size(X, 1), 1);

%% Forward Propagation (Vectorized Form)
h1 = [ones(m, 1) X] * Theta1';
y1 = h1;
y1(y1 <= 0) = 0;
h2 = [ones(m, 1) y1] * Theta2';
y2 = h2;

% y2 is the output of the neural network (in this case we have only two
% layers, namely one hidden and one output layer)
if num_labels == 1
    p = sign(y2);
    p = bsxfun(@plus,p,1)./2;
else
    [dummy, p] = max(y2, [], 2);
end
end
