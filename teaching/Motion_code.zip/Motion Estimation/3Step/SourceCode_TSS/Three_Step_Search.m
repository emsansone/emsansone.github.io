close all;
clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONFIGURATION PARAMS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filenameOrig='../Stefan_rid.yuv';% here you have to specify the address of the original video sequence.

input=0; % 0 = YUV420
         % 1 = YUV444

nFrames=50; %number fo frames you want to code.

numR=288;
numC=352;

numROut = 288;
numCOut = 352;

ratioR = numR/numROut;
ratioC = numC/numCOut;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fnameOut=[filenameOrig(1:end-4) '_to_' int2str(numCOut) 'x' int2str(numROut) '.yuv'];

% Open File to Read
fy=fopen(filenameOrig,'rb');
fp=fopen(filenameOrig,'rb');

% Open Files to Write
fout=fopen(fnameOut,'wb');
fErr=fopen('ImmErr.yuv','wb');
fDiff=fopen('ImmDiff.yuv','wb');

% R legge frame N+1, Y legge frame N  
if (input)
   R = fread(fp,3*numR*numC,'uint8',0);
else
   R = fread(fp,(3/2)*numR*numC,'uint8',0);
end    

for k=1:nFrames-1
    k
    Y = fread(fy,numR*numC,'uint8',0);
    Y = imresize(reshape(Y, numC, numR)', [numROut numCOut]);
    R = fread(fp,numR*numC,'uint8',0);
    R = imresize(reshape(R, numC, numR)', [numROut numCOut]);
    D = R-Y;
    if(input)
        U = fread(fy,numR*numC,'uint8',0);
        U = imresize(reshape(U, numC, numR)', [numROut/2 numCOut/2]);
        V = fread(fy,numR*numC,'uint8',0);
        V = imresize(reshape(V, numC, numR)', [numROut/2 numCOut/2]);
        Up = fread(fp,numR*numC,'uint8',0);
        Up = imresize(reshape(Up, numC, numR)', [numROut/2 numCOut/2]);
        Vp = fread(fp,numR*numC,'uint8',0);
        Vp = imresize(reshape(Vp, numC, numR)', [numROut/2 numCOut/2]);
    else
        U = fread(fy,numR*numC/4,'uint8',0);
        U = imresize(reshape(U, numC/2, numR/2)', [numROut/2 numCOut/2]);
        V = fread(fy,numR*numC/4,'uint8',0);
        V = imresize(reshape(V, numC/2, numR/2)', [numROut/2 numCOut/2]);
        Up = fread(fp,numR*numC/4,'uint8',0);
        Up = imresize(reshape(Up, numC/2, numR/2)', [numROut/2 numCOut/2]);
        Vp = fread(fp,numR*numC/4,'uint8',0);
        Vp = imresize(reshape(Vp, numC/2, numR/2)', [numROut/2 numCOut/2]);
    end
    
    
    % Allocazione memoria
    
    % Dimensione MB 
    MB_size = 8;
    
    % MC_Image: Immagine Compensata
    MC_Image = zeros(numR, numC);
    % Error_Immage: Immagine rappresentante l'errore
    Error_Image = zeros(numR, numC);
    % MotionVector: Matrice dei Motion_Vector 
    MotionVector = zeros(2, numR*numC/MB_size^2);
    % Distance: matrice 3x3 contenete l'errore dei 9 punti selezionati nel 3Step
    Distance = ones(3,3)*2^15;
        
    % Calcolo il numero massimo di MB per riga e per colonna
    MaxR = numR-MB_size+1;
    MaxC = numC-MB_size+1;
    
    % Creo una matrice con la posizione di ogni MB per disegnare poi i MVs
    c=1;
    for i=MaxR:-MB_size:1
        for j=1:MB_size:MaxC
            MB_pos(1,c)=j+floor((MB_size-1)/2);
            MB_pos(2,c)=i+floor((MB_size-1)/2);
            c=c+1;
        end
    end
    
    % Calcolo Step Max
    Range = 7; % Range dispari 3, 7, 15..
    Step_max=floor(Range/2)+1;
    
    % Mi posizione nel primo MB
    num_MB = 1;
    
    % Inizio ricerca per ogni MB del frame
    
    % Scorro tutte le righe
    for i=1:MB_size:MaxR
        % Scorro tutte le colonne
        for j=1:MB_size:MaxC
            
            x = j;
            y = i;
            
            % Calcolo errore nel centro della finestra di ricerca tra frame
            % corrente e MB nella stessa posizione nel frame di riferimento
            % fuori dal ciclo solo per il primo Step
            Distance(2,2) = MAD(Y(i:i+MB_size-1,j:j+MB_size-1), R(i:i+MB_size-1,j:j+MB_size-1));
            
            % Inizilamente lo step_size deve essere massimo
            Step_size = Step_max;
            
            index = 1;
            % Fino a quando lo step_size non diventa uguale a 1 eseguo iterazione della ricerca
            %while (Step_size >= 1)
            while (index <= 3)   
            
                % Calcolo errore per gli altri 8 punti vicini al centro a
                % distanza Step_size tra loro
                for m = -Step_size:Step_size:Step_size % m indice righe
                    for n = -Step_size:Step_size:Step_size % n indice colonne
                        Index_ver = y+m; % indice righe generale
                        Index_or = x+n; % indice colonne generale
                        
                        % Verfico che il punto in questione non sia fuori
                        % dal frame
                        if (Index_ver<1 || Index_ver+MB_size-1>numR || Index_or<1 || Index_or+MB_size-1>numC)
                            continue
                        end
                        
                        % posR e posC mi danno gli indici (1,2,3) della matrice 3x3
                        % contenete gli errori 
                        posR = m/Step_size +2;
                        posC = n/Step_size +2;
                        
                        % Verifico che non sia il punto centrale perch? ?
                        % gi? stato calcolato prima
                        if (posR == 2 && posC == 2)
                            continue
                        end
                        
                        % Calcolo l'errore tra il MB nel frame corrente e gli 8 MB vicini a quello
                        % calcolato nel centro
                        Distance(posR, posC) = MAD(Y(i:i+MB_size-1,j:j+MB_size-1), R(Index_ver:Index_ver+MB_size-1,Index_or:Index_or+MB_size-1));
                    end
                end
                
                % Cerco il punto con l'errore minimo e lo salvo come nuovo
                % centro dell'area di ricerca 
                [Index_y, Index_x] = find_min_distance(Distance);
                Distance(2,2) = Distance(Index_y, Index_x);
                
                % Mi riporto alle coordinate originali per il punto trovato
                x= x+(Index_x-2)*Step_size;
                y= y+(Index_y-2)*Step_size;
                
                % Dimezzo lo Step_size
                Step_size = Step_size/2;
                index = index + 1;
                
            end
            
            % Una volta che lo Step_size ? uguale a uno calcolo lo
            % spostamento dal blocco originale (x,y punto trovato, j,i punto originale)
            MotionVector(1, num_MB) = y-i;
            MotionVector(2, num_MB) = x-j;
            
%             y_coor = MotionVector(1, num_MB);
%             x_coor = MotionVector(2, num_MB);
%             Index_ver = i + y_coor;
%             Index_or = j + x_coor;
%               Index_ver = y;
%               Index_or = x;
              MC_Image(i:i+MB_size-1,j:j+MB_size-1) = R(y:y+MB_size-1, x:x+MB_size-1);
            
            % Rieseguo tutto per un nuovo MB
            num_MB = num_MB+1;
            Distance = ones(3,3)*2^15;
        end
    end
    hf = figure(1);
    set(hf, 'position', [200 300 numC numR]);
    MVs=quiver(MB_pos(1,:),MB_pos(2,:),MotionVector(2,:),MotionVector(1,:));
    
    
    Y_col = reshape(Y,size(Y,1)*size(Y,2),1);
    U_col = zeros(size(Y,1),size(Y,2));
    V_col = zeros(size(Y,1),size(Y,2));
    if(input)
        U_col = reshape(U,size(U,1)*size(U,2),1);
        V_col = reshape(V,size(V,1)*size(V,2),1);
    else
        % Bilinear interpolation
        for i = 1:numR
           for j = 1:numC
              if rem(i,2)*rem(j,2) ~= 0
                 U_col(i,j) = U(((i-1)/2)+1,((j-1)/2)+1);
                 V_col(i,j) = V(((i-1)/2)+1,((j-1)/2)+1);                                          
              end
           end
        end
        for i = 1:numR
           for j = 1:numC
              if rem(i,2)*rem(j,2) == 0
                  if rem(i,2) == rem(j,2)
                       if i ~= numR && j ~= numC 
                         U_col(i,j) = (U(i/2,j/2)+U(i/2+1,j/2)+U(i/2,j/2+1)+U(i/2+1,j/2+1))/4;
                         V_col(i,j) = (V(i/2,j/2)+V(i/2+1,j/2)+V(i/2,j/2+1)+V(i/2+1,j/2+1))/4;
                       end
                  else
                     if rem(i,2) == 0
                        if i ~= numR && j ~= numC 
                             U_col(i,j) = (U(i/2,((j-1)/2)+1)+U(i/2+1,((j-1)/2)+1))/2;
                             V_col(i,j) = (V(i/2,((j-1)/2)+1)+V(i/2+1,((j-1)/2)+1))/2;  
                        end
                     else
                         if i ~= numR && j ~= numC 
                             U_col(i,j) = (U(((i-1)/2)+1,j/2)+U(((i-1)/2)+1,j/2+1))/2;
                             V_col(i,j) = (V(((i-1)/2)+1,j/2)+V(((i-1)/2)+1,j/2+1))/2;
                         end
                     end
                  end
              end
           end
        end
    end
    frame(:,:,1) = Y./max(max(Y));
    frame(:,:,2) = U_col./max(max(Y));
    frame(:,:,3) = V_col./max(max(Y));
    rgbmap = ycbcr2rgb(frame);
        
    hf2 = figure(2);
    set(hf2, 'position', [800 300 numC numR]);
    imshow(rgbmap);
    axis ([-10 360 -10 300]);
    title(sprintf('%d',k));
    figure(1);
    M(k)=getframe(gcf); % get current figure
    Error_Image = Y-MC_Image;
   
    % Scrittura file   
    fwrite(fout, MC_Image', 'uint8');
    fwrite(fout, U', 'uint8');
    fwrite(fout, V', 'uint8');
    
    fwrite(fErr, Error_Image', 'uint8');
    fwrite(fErr, U', 'uint8');
    fwrite(fErr, V', 'uint8');
    
    fwrite(fDiff, D', 'uint8');
    fwrite(fDiff, U', 'uint8');
    fwrite(fDiff, V', 'uint8');
   
end

movie2avi(M, 'MVs.avi', 'compression', 'None');

fclose('all');