% Computes the Mean Absolute Difference (MAD) for the given two blocks
% 
% Input
%       currentBlk : the block for which it is finding the MAD
%       refBlk : the block w.r.t. which the MAD is being computed
%       n : the side of the two square blocks
%
% Output
%       cost : the MAD for the two blocks



function cost = costFuncMAD(currentBlk, refBlk, n)

err = 0;
err = sum(sum(abs(currentBlk - refBlk)));
cost = err / (n*n);



