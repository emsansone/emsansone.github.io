% This function computes the motion vectors
%
% Input
%   imgP : The image for which we want to find motion vectors
%   imgI : The reference image
%   mbSize : Size of the macroblock
%
% Ouput
%   motionVect : the motion vectors for each integral macroblock in imgP
%   EScomputations: the average number of points searched for a macroblock


function [motionVect, EScomputations] = motionEstES_3channels(imgP, imgI, mbSize)

[row] = size(imgI,1);
[col] = size(imgI,2);
file_1 = fopen('errors.txt','w');
vectors = zeros(2,row*col/mbSize^2);
costs_1 = ones(row , col) * 16777217;
costs_2 = ones(row , col) * 16777217;
costs_3 = ones(row , col) * 16777217;
computations = 0;
err_tot = 0;
mbCount = 1;

%Raster scanning of the macroblocks in the anchor frame
for i = 1 : mbSize : row-mbSize+1
    for j = 1 : mbSize : col-mbSize+1
        
        %It calculates the matrix of costs for every macroblock
        for m = 1 : mbSize : row-mbSize+1       % m is row(vertical) index
            for n = 1 : mbSize : col-mbSize+1   % n is col(horizontal) index
                costs_1(m,n) = costFuncMAD(imgI(i:i+mbSize-1,j:j+mbSize-1,1), imgP(m:m+mbSize-1,n:n+mbSize-1,1), mbSize);
                costs_2(m,n) = costFuncMAD(imgI(i:i+mbSize-1,j:j+mbSize-1,2), imgP(m:m+mbSize-1,n:n+mbSize-1,2), mbSize);
                costs_3(m,n) = costFuncMAD(imgI(i:i+mbSize-1,j:j+mbSize-1,3), imgP(m:m+mbSize-1,n:n+mbSize-1,3), mbSize);
                costs = costs_1 + costs_2 + costs_3;
                computations = computations + 1;
            end
        end
        
        %Now it is found and stored the vector in which the cost is minimum 
        [dx, dy, min] = minCost(costs, i, j);  
        err_tot = err_tot + (min*(mbSize^2));  
        fprintf ( file_1,'%s%d','Error_32 = ',err_tot);
        fprintf ( file_1,'\n');
        
        %It draws a black grid on the frame
        M = size(imgI,1);
        N = size(imgI,2);
        for k = 1:mbSize:M+1
            x = [1 N];
            y = [k k];
            plot(x,y,'Color','k','LineStyle','-');
        end
        for k = 1:mbSize:N+1
            x = [k k];
            y = [1 M];
            plot(x,y,'Color','k','LineStyle','-');
        end
        
        %It draws the results on the anchor frame
        if (dx == i && dy == j)
            line([j+(mbSize/2) j+(mbSize/2)], [i+(mbSize/2) i+(mbSize/2)], 'Marker', 'x', 'MarkerSize', 5 , 'Color','b');
        else
            quiver( j+(mbSize/2),i+(mbSize/2),dy-j,dx-i,'Color','b','LineWidth',3);
            %line([j+(mbSize/2) (mbSize/2)+(dy)], [i+(mbSize/2),(mbSize/2)+(dx)]);
        end
        
        mbCount = mbCount + 1;
        costs_1 = ones(row , col) * 16777217;
        costs_2 = ones(row , col) * 16777217;
        costs_3 = ones(row , col) * 16777217;
    end
end
fclose (file_1);
motionVect = vectors;
EScomputations = computations/(mbCount - 1);
